package edu.taskboard.taskboard.security;

import edu.taskboard.taskboard.model.User;
import edu.taskboard.taskboard.service.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.Map;
import java.util.function.Function;

@Service
public class JWTService {

    private final String ENCRYPTION_KEY = "ZEfhxuE8iIiR73KAvADHftryMzvwi523kf3vWLyBxlhWA47cFeZ9fpJlzML2bGD9";
    private final UserService userService;

    public JWTService(UserService userService) {
        this.userService = userService;
    }

    public Map<String, String> generate(String username) {
        User user = (User) userService.loadUserByUsername(username);
        return generateJwt(user);
    }

    public Map<String, String> generateJwt(User user) {
        long now = System.currentTimeMillis();
        long expiry = now + 30 * 60 * 1000; // 30 minutes

        Claims claims = Jwts.claims()
                .setSubject(user.getEmail())
                .setExpiration(new Date(expiry))
                .setIssuedAt(new Date(now));
        claims.put("nom", user.getName());

        String token = Jwts.builder()
                .setClaims(claims)
                .signWith(getKey(), SignatureAlgorithm.HS256)
                .compact();

        return Map.of("bearer", token);
    }

    public String getUserName(String token) {
        return getClaim(token, Claims::getSubject);
    }

    public boolean isTokenExpired(String token) {
        return getExpirationDateFromToken(token).before(new Date());
    }

    private Date getExpirationDateFromToken(String token) {
        return getClaim(token, Claims::getExpiration);
    }

    private <T> T getClaim(String token, Function<Claims, T> claimsResolver) {
        return claimsResolver.apply(getAllClaims(token));
    }

    private Claims getAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    private Key getKey() {
        byte[] keyBytes = Decoders.BASE64.decode(ENCRYPTION_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
